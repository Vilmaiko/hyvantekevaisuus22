function openNav() {
    document.getElementById("kehys1").style.display = "none";
    document.getElementById("Sidebars").style.width = "250px";
    document.getElementById("SideBarBtn").style.display = "none";
    document.getElementById("main").style.marginLeft = "250px";
  }  
  function closeNav() {
    document.getElementById("kehys1").style.display = "block";
    document.getElementById("SideBarBtn").style.display = "block";
    document.getElementById("Sidebars").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  }